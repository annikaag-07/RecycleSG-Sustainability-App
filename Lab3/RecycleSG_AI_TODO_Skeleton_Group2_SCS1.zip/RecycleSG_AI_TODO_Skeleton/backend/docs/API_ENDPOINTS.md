<!-- TODO: Document this area for the full application. -->
